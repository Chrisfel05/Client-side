$('.carousel-item').carousel({
interval: 2000