alert("JS is working");
//Regular Expression to use

var myidcheck = /^([0-9]{4,4})(2020)$/gm;
var regpass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])\w{6,}$/;

//Edit the html for the necessary addition 

//Create a function that validate the search field using the regular expression above

//Create a function that checks if any gender has been selected

//Create a function to check if the selected item is 'CS'

//A function to be excuted when the search button is clicked. 
//This function calls all other functions
function validate(){
	function checkPassword();

	//call function to validate search field
	//call function for gender
	//call funtion for select item
}

//In all cases, provide appropriate alert to indicate the status of validation

//Edit the html for the necessary addition

//sample function
function checkPassword(){
	alert("JS is working");
	var checkp = document.getElementById("pass1").value;
	var result = regpass.test(checkp);
	//condition to validate
	if(!result){
		alert("Error: Password must contain at least one number, one lowercase and one uppercase letter and at least six characters that are letters, numbers or the underscore")
		return false;
	}
	if(checkp == ""){
		alert("The password cannot be empty");
	}
	
	
	//if true alert results and continue
	//if false alert results and exit
	//to exit just use the command "return false;"
}