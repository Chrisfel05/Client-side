(function ($) {
 "use strict";

		$('a.media').media({width:630, height:950});
		 
 
})(jQuery); 